<?php require_once __DIR__ . '/helpers.php';
$total = hitungTotal(25000, 3);
?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>Halaman B</title></head>
<body>
<h1>Halaman B - Total belanja</h1>
<p>Harga satuan: <?= formatRupiah(25000) ?>, jumlah: 3</p>
<p>Total: <strong><?= formatRupiah($total) ?></strong></p>
<p>Nilai 90 -> predikat <?= tentukanStatusNilai(90) ?></p>
<p><a href="halaman-a.php">Ke Halaman A</a></p>
</body></html>
