<?php
/** Memformat angka menjadi format Rupiah, mis. Rp 150.000 */
function formatRupiah(float $angka): string {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

/** Escaping teks sebelum ditampilkan ke HTML. */
function e(string $nilai): string {
    return htmlspecialchars($nilai, ENT_QUOTES, 'UTF-8');
}

/** Latihan 1: konversi Celcius ke Fahrenheit. */
function konversiCelciusKeFahrenheit(float $c): float {
    return ($c * 9 / 5) + 32;
}

/** Latihan 2: predikat nilai (A>=85, B>=70, C>=55, D>=40, selain itu E). */
function tentukanStatusNilai(float $nilai): string {
    if ($nilai >= 85) return 'A';
    if ($nilai >= 70) return 'B';
    if ($nilai >= 55) return 'C';
    if ($nilai >= 40) return 'D';
    return 'E';
}

/** Latihan 3: total belanja. */
function hitungTotal(float $harga, int $jumlah): float {
    return $harga * $jumlah;
}
