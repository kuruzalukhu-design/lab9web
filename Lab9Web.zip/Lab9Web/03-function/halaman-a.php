<?php require_once __DIR__ . '/helpers.php'; ?>
<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8"><title>Halaman A</title></head>
<body>
<h1>Halaman A - Konversi suhu &amp; nilai</h1>
<p>36,6 &deg;C = <?= konversiCelciusKeFahrenheit(36.6) ?> &deg;F</p>
<p>100 &deg;C = <?= konversiCelciusKeFahrenheit(100) ?> &deg;F</p>
<p>Nilai 88 -> predikat <?= tentukanStatusNilai(88) ?></p>
<p>Nilai 62 -> predikat <?= tentukanStatusNilai(62) ?></p>
<p>Nilai 30 -> predikat <?= tentukanStatusNilai(30) ?></p>
<p><a href="halaman-b.php">Ke Halaman B</a></p>
</body></html>
