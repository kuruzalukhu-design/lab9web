# Praktik: menguji include dan require

1. Buka `uji-include.php` -> ketiga baris tampil.
2. Ubah nama `pesan.php` menjadi `pesan-x.php`, lalu buka lagi `uji-include.php`:
   muncul **Warning**, tetapi baris "Sesudah pemanggilan" **tetap tampil**.
3. Buka `uji-require.php` (nama file masih salah): muncul **Fatal error**,
   baris "Sesudah pemanggilan" **tidak tampil** (eksekusi berhenti).
4. Kembalikan nama file menjadi `pesan.php`.
