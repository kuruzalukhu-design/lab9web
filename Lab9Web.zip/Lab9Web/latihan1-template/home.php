<?php $judul = 'Home'; $aktif = 'home'; require_once __DIR__ . '/header.php'; ?>
<section class="content">
 <h2>Selamat Datang</h2>
 <p>Ini halaman beranda. Header dan footer berasal dari file template bersama.</p>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
