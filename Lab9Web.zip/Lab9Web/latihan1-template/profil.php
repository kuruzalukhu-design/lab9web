<?php $judul = 'Profil'; $aktif = 'profil'; require_once __DIR__ . '/header.php'; ?>
<section class="content">
 <h2>Profil</h2>
 <table>
  <tr><th>Nama</th><td>Isi nama Anda</td></tr>
  <tr><th>NIM</th><td>Isi NIM Anda</td></tr>
  <tr><th>Mata Kuliah</th><td>Pemrograman Web</td></tr>
 </table>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
