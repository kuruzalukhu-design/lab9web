<?php
// $judul dan $aktif diisi oleh halaman sebelum header dipanggil
$judul = $judul ?? 'Aplikasi PHP Modular';
$aktif = $aktif ?? '';
$menu  = ['home' => 'Home', 'profil' => 'Profil', 'kontak' => 'Kontak'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title><?= htmlspecialchars($judul, ENT_QUOTES, 'UTF-8') ?> - Latihan 1</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
 <header>
 <h1>Latihan 1 - Template Multi-halaman</h1>
 <p>Home, Profil, dan Kontak memakai header &amp; footer yang sama</p>
 </header>
 <nav>
 <?php foreach ($menu as $file => $label): ?>
 <a href="<?= $file ?>.php"<?= $aktif === $file ? ' class="active"' : '' ?>><?= $label ?></a>
 <?php endforeach; ?>
 </nav>
 <main>
