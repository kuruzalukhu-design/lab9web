<?php $judul = 'Kontak'; $aktif = 'kontak'; require_once __DIR__ . '/header.php'; ?>
<section class="content">
 <h2>Kontak</h2>
 <p>Email: praktikum@example.com</p>
 <p>Alamat: Laboratorium Komputer</p>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
