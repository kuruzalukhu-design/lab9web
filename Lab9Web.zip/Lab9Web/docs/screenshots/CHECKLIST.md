# Daftar Screenshot

Sudah tersedia (dibuat otomatis dari isi repository):
`01-struktur-direktori.png`, `05-kode-header.png`, `06-kode-footer.png`, `12-kode-helpers.png`, `18-kode-router.png`

Perlu diambil dari browser setelah aplikasi dijalankan di localhost (simpan di folder ini dengan nama berikut):

| File | URL |
|---|---|
| 02-include-normal.png | /01-include-require/uji-include.php |
| 03-include-error.png | uji-include.php saat `pesan.php` diganti nama |
| 04-require-error.png | /01-include-require/uji-require.php saat `pesan.php` diganti nama |
| 07-template-home.png | /02-template/home.php |
| 08-template-about.png | /02-template/about.php |
| 09-latihan1-home.png | /latihan1-template/home.php |
| 10-latihan1-profil.png | /latihan1-template/profil.php |
| 11-latihan1-kontak.png | /latihan1-template/kontak.php |
| 13-function-contoh.png | /03-function/contoh-function.php |
| 14-function-halaman-a.png | /03-function/halaman-a.php |
| 15-function-halaman-b.png | /03-function/halaman-b.php |
| 16-latihan2-produk.png | /latihan2-function/index.php |
| 17-latihan2-email.png | /latihan2-function/daftar.php (setelah submit) |
| 19-routing-dashboard.png | /latihan4-crud/index.php |
| 20-routing-user-list.png | /latihan4-crud/index.php?page=user/list |
| 21-routing-user-add.png | /latihan4-crud/index.php?page=user/add |
| 22-routing-404.png | /latihan4-crud/index.php?page=admin/rahasia |
| 23-routing-wajib-login.png | user/list tanpa login (diarahkan ke login) |
| 24-login.png | /latihan4-crud/index.php?page=login |
| 25-crud-tambah.png | setelah tambah pengguna |
| 26-crud-validasi.png | form dengan email tidak valid |
| 27-crud-edit.png | setelah edit pengguna |
| 28-crud-hapus.png | setelah hapus pengguna |
