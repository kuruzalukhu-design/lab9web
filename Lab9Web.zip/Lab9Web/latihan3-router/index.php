<?php
// Router sederhana dengan whitelist. Input URL TIDAK pernah dipakai sebagai path file.
$routes = [
    'home'   => __DIR__ . '/views/home.php',
    'about'  => __DIR__ . '/views/about.php',
    'produk' => __DIR__ . '/views/produk.php',
    'kontak' => __DIR__ . '/views/kontak.php',
    'faq'    => __DIR__ . '/views/faq.php',
];

$page = $_GET['page'] ?? 'home';

// page kosong -> beranda; bukan string (mis. ?page[]=x) atau tidak terdaftar -> 404
if ($page === '') {
    $page = 'home';
}
if (!is_string($page) || !array_key_exists($page, $routes)) {
    http_response_code(404);
    $page = '404';
    $contentFile = __DIR__ . '/views/404.php';
} else {
    $contentFile = $routes[$page];
}

require_once __DIR__ . '/views/header.php';
require $contentFile;
require_once __DIR__ . '/views/footer.php';
