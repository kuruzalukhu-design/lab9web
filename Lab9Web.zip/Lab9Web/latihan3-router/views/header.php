<?php
$menu = [
    'home'    => 'Home',
    'about'   => 'Tentang',
    'produk'  => 'Produk',
    'kontak'  => 'Kontak',
    'faq'     => 'FAQ',
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title>Latihan 3 - Router Aman</title>
 <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="container">
 <header><h1>Latihan 3 - Router Aman</h1><p>Semua halaman lewat index.php?page=...</p></header>
 <nav>
 <?php foreach ($menu as $kode => $label): ?>
  <a href="index.php?page=<?= $kode ?>"<?= ($page === $kode) ? ' class="active"' : '' ?>><?= $label ?></a>
 <?php endforeach; ?>
 </nav>
 <main>
