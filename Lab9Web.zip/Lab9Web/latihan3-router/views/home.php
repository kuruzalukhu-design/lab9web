<section>
 <h2>Halaman Home</h2>
 <p>Selamat datang di latihan router.</p>
</section>
