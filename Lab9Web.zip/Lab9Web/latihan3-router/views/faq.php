<section>
 <h2>FAQ</h2>
 <p>Pertanyaan yang sering diajukan.</p>
</section>
