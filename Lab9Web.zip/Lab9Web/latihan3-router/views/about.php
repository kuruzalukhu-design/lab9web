<section>
 <h2>Tentang</h2>
 <p>Halaman ini dimuat oleh router melalui whitelist.</p>
</section>
