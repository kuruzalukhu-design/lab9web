<section>
 <h2>Produk</h2>
 <p>Daftar produk contoh akan tampil di sini.</p>
</section>
