<section>
 <h2>Kontak</h2>
 <p>Email: praktikum@example.com</p>
</section>
