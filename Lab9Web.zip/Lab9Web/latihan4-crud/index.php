<?php
// index.php - titik masuk aplikasi sekaligus router (whitelist rute)
session_start();
ob_start(); // modul boleh melakukan redirect setelah memproses form

require_once __DIR__ . '/config/database.php';      // wajib -> $pdo
require_once __DIR__ . '/helpers/functions.php';

// Whitelist rute. 'auth' => true berarti harus login terlebih dahulu.
$routes = [
    'dashboard'   => ['file' => __DIR__ . '/views/dashboard.php',        'title' => 'Dashboard',          'auth' => true],
    'login'       => ['file' => __DIR__ . '/modules/auth/login.php',     'title' => 'Login',              'auth' => false],
    'logout'      => ['file' => __DIR__ . '/modules/auth/logout.php',    'title' => 'Logout',             'auth' => false],
    'user/list'   => ['file' => __DIR__ . '/modules/user/list.php',      'title' => 'Data Pengguna',      'auth' => true],
    'user/add'    => ['file' => __DIR__ . '/modules/user/add.php',       'title' => 'Tambah Pengguna',    'auth' => true],
    'user/edit'   => ['file' => __DIR__ . '/modules/user/edit.php',      'title' => 'Edit Pengguna',      'auth' => true],
    'user/delete' => ['file' => __DIR__ . '/modules/user/delete.php',    'title' => 'Hapus Pengguna',     'auth' => true],
];

$page = $_GET['page'] ?? 'dashboard';
if ($page === '') {
    $page = 'dashboard';
}

if (!is_string($page) || !array_key_exists($page, $routes)) {
    http_response_code(404);
    $currentPage = '404';
    $pageTitle   = '404 - Tidak ditemukan';
    $contentFile = __DIR__ . '/views/404.php';
} else {
    $route = $routes[$page];
    if ($route['auth'] && !is_logged_in()) {
        flash_set('error', 'Silakan login terlebih dahulu.');
        redirect(url('login'));
    }
    $currentPage = $page;
    $pageTitle   = $route['title'];
    $contentFile = $route['file'];
}

// Jalankan konten dulu (agar redirect/POST dapat diproses sebelum ada output)
ob_start();
require $contentFile;
$content = ob_get_clean();

require_once __DIR__ . '/views/header.php';
echo $content;
require_once __DIR__ . '/views/footer.php';
