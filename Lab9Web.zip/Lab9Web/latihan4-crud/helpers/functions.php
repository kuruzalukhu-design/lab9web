<?php
/* ===== Tampilan & URL ===== */

/** Escape output HTML. */
function e($nilai): string {
    return htmlspecialchars((string) $nilai, ENT_QUOTES, 'UTF-8');
}

/** Folder tempat aplikasi berjalan (mis. /Lab9Web/latihan4-crud). */
function base_url(): string {
    $dir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? ''));
    return rtrim($dir, '/');
}

/** URL ke sebuah rute: url('user/edit', ['id' => 3]) -> .../index.php?page=user/edit&id=3 */
function url(string $page = 'dashboard', array $params = []): string {
    $query = http_build_query(array_merge(['page' => $page], $params));
    return base_url() . '/index.php?' . str_replace('%2F', '/', $query);
}

/** URL aset statis (css/js/gambar). Konsisten walau URL berubah karena rewrite. */
function asset(string $path): string {
    return base_url() . '/assets/' . ltrim($path, '/');
}

/** Redirect aman: buang output yang sudah di-buffer lalu kirim header Location. */
function redirect(string $location): void {
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    header('Location: ' . $location);
    exit;
}

/** Menu aktif: true jika rute saat ini sama dengan / berada di bawah salah satu prefix. */
function is_active(string $current, string ...$prefixes): bool {
    foreach ($prefixes as $p) {
        if ($current === $p || strpos($current, $p . '/') === 0) {
            return true;
        }
    }
    return false;
}

/* ===== Flash message (pesan sukses/gagal) ===== */

function flash_set(string $tipe, string $pesan): void {
    $_SESSION['flash'][] = ['tipe' => $tipe, 'pesan' => $pesan];
}

function flash_render(): string {
    if (empty($_SESSION['flash'])) {
        return '';
    }
    $html = '';
    foreach ($_SESSION['flash'] as $f) {
        $kelas = $f['tipe'] === 'success' ? 'success' : 'error';
        $html .= '<div class="flash ' . $kelas . '">' . e($f['pesan']) . '</div>';
    }
    unset($_SESSION['flash']);
    return $html;
}

/* ===== Keamanan: CSRF ===== */

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_verify(): void {
    $kirim = $_POST['csrf'] ?? '';
    if (!is_string($kirim) || !hash_equals($_SESSION['csrf'] ?? '', $kirim)) {
        http_response_code(419);
        exit('Token keamanan tidak valid. Muat ulang halaman lalu coba lagi.');
    }
}

/* ===== Autentikasi ===== */

function is_logged_in(): bool {
    return !empty($_SESSION['user']);
}

/* ===== Validasi & input ===== */

/** Ambil input POST bertipe string (trim); selain string dianggap kosong. */
function post_string(string $key): string {
    $v = $_POST[$key] ?? '';
    return is_string($v) ? trim($v) : '';
}

function validasiEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/** Ambil id positif dari $_GET['id']; null jika tidak valid. */
function get_id(): ?int {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
    return ($id === false || $id === null) ? null : $id;
}

/**
 * Validasi data pengguna. $idSaatIni dipakai saat edit agar email sendiri tidak dianggap duplikat.
 * @return string[] daftar pesan error (kosong jika valid)
 */
function validasi_user(PDO $pdo, string $nama, string $email, string $password, bool $passwordWajib, ?int $idSaatIni = null): array {
    $err = [];
    if ($nama === '' || mb_strlen($nama, 'UTF-8') > 100) {
        $err[] = 'Nama wajib diisi (maksimal 100 karakter).';
    }
    if (!validasiEmail($email) || mb_strlen($email, 'UTF-8') > 100) {
        $err[] = 'Format email tidak valid.';
    } else {
        $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id <> :id');
        $stmt->execute([':email' => $email, ':id' => $idSaatIni ?? 0]);
        if ($stmt->fetch()) {
            $err[] = 'Email sudah digunakan pengguna lain.';
        }
    }
    if ($passwordWajib && $password === '') {
        $err[] = 'Password wajib diisi.';
    }
    if ($password !== '' && strlen($password) < 6) {
        $err[] = 'Password minimal 6 karakter.';
    }
    return $err;
}

function formatTanggal(?string $datetime): string {
    if (!$datetime) {
        return '-';
    }
    return date('d-m-Y H:i', strtotime($datetime));
}
