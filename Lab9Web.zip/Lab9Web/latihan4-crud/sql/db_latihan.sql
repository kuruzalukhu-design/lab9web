-- Database untuk Lab9Web (Praktikum 9)
CREATE DATABASE IF NOT EXISTS db_latihan CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_latihan;

DROP TABLE IF EXISTS users;
CREATE TABLE users (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Akun login: admin@example.com / admin123 ; lainnya: password123
INSERT INTO users (nama, email, password) VALUES
('Administrator', 'admin@example.com', '$2b$12$Hgpe6nQl04Lhh.8WkJTB.Oqv.9VoYzM8EhkmJgCugAOEp6DiV0ji.'),
('Rina Putri', 'rina@example.com', '$2b$12$hI.f7Q/Tu0RWDVHpSv4z1ud.LPdVGdBBPZaocii2./d4riBTDmUXe'),
('Budi Santoso', 'budi@example.com', '$2b$12$7MrlDff2kRyqsN9HdaWhbONzKBkJL0DunHAeX2kAMDDC1J7i2esIS');
