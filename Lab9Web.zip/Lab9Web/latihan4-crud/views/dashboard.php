<?php
$total   = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$terbaru = $pdo->query('SELECT id, nama, email, created_at FROM users ORDER BY id DESC LIMIT 5')->fetchAll();
?>
<section>
 <h2>Dashboard</h2>
 <div class="cards">
  <div class="card"><strong><?= $total ?></strong>Total pengguna</div>
 </div>
 <h3>5 Pengguna Terbaru</h3>
 <table>
  <tr><th>Nama</th><th>Email</th><th>Dibuat</th></tr>
  <?php foreach ($terbaru as $u): ?>
  <tr><td><?= e($u['nama']) ?></td><td><?= e($u['email']) ?></td><td><?= e(formatTanggal($u['created_at'])) ?></td></tr>
  <?php endforeach; ?>
 </table>
 <p><a class="btn" href="<?= e(url('user/list')) ?>">Kelola Pengguna</a></p>
</section>
