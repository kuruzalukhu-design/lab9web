 </main>
 <footer>
  <p>&copy; <?php echo date('Y'); ?> - Praktikum Pemrograman Web</p>
 </footer>
</div>
<script src="<?= e(asset('js/app.js')) ?>"></script>
</body>
</html>
