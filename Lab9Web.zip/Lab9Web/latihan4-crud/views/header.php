<!DOCTYPE html>
<html lang="id">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title><?= e($pageTitle ?? 'Aplikasi') ?> - Lab9Web</title>
 <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
</head>
<body>
<div class="container">
 <header>
  <h1>Lab9Web - Manajemen Pengguna</h1>
  <p>CRUD modular dengan template, helper, dan router</p>
 </header>
 <nav>
  <?php if (is_logged_in()): ?>
   <a href="<?= e(url('dashboard')) ?>"<?= is_active($currentPage, 'dashboard') ? ' class="active"' : '' ?>>Dashboard</a>
   <a href="<?= e(url('user/list')) ?>"<?= is_active($currentPage, 'user') ? ' class="active"' : '' ?>>Pengguna</a>
   <span class="spacer">Halo, <?= e($_SESSION['user']['nama']) ?></span>
   <form class="inline" method="post" action="<?= e(url('logout')) ?>">
    <?= csrf_field() ?>
    <button type="submit" class="btn link">Logout</button>
   </form>
  <?php else: ?>
   <a href="<?= e(url('login')) ?>"<?= is_active($currentPage, 'login') ? ' class="active"' : '' ?>>Login</a>
  <?php endif; ?>
 </nav>
 <main>
  <?= flash_render() ?>
