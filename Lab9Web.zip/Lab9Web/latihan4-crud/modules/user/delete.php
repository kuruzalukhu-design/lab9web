<?php
// Penghapusan hanya lewat POST + token CSRF; membuka URL (GET) tidak menghapus data.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    flash_set('error', 'Penghapusan harus dilakukan melalui tombol Hapus.');
    redirect(url('user/list'));
}
csrf_verify();

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
if ($id === false || $id === null) {
    flash_set('error', 'ID pengguna tidak valid.');
    redirect(url('user/list'));
}
if ($id === ($_SESSION['user']['id'] ?? 0)) {
    flash_set('error', 'Anda tidak dapat menghapus akun yang sedang dipakai.');
    redirect(url('user/list'));
}

$stmt = $pdo->prepare('DELETE FROM users WHERE id = :id');
$stmt->execute([':id' => $id]);
$ok = $stmt->rowCount() > 0;
flash_set($ok ? 'success' : 'error', $ok ? 'Pengguna berhasil dihapus.' : 'Pengguna tidak ditemukan.');
redirect(url('user/list'));
