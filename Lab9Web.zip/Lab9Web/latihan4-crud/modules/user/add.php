<?php
$errors = [];
$nama = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $nama     = post_string('nama');
    $email    = post_string('email');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';

    $errors = validasi_user($pdo, $nama, $email, $password, true);
    if (!$errors) {
        $stmt = $pdo->prepare('INSERT INTO users (nama, email, password) VALUES (:nama, :email, :password)');
        $stmt->execute([
            ':nama'     => $nama,
            ':email'    => $email,
            ':password' => password_hash($password, PASSWORD_DEFAULT),
        ]);
        flash_set('success', 'Pengguna berhasil ditambahkan.');
        redirect(url('user/list'));
    }
}
?>
<section>
 <h2>Tambah Pengguna</h2>
 <?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>
 <form method="post" action="<?= e(url('user/add')) ?>">
  <?= csrf_field() ?>
  <div class="form-group"><label>Nama</label><input type="text" name="nama" value="<?= e($nama) ?>" required></div>
  <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($email) ?>" required></div>
  <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
  <button class="btn" type="submit">Simpan</button>
  <a href="<?= e(url('user/list')) ?>">Batal</a>
 </form>
</section>
