<?php
$users = $pdo->query('SELECT id, nama, email, created_at FROM users ORDER BY id ASC')->fetchAll();
?>
<section>
 <h2>Data Pengguna</h2>
 <p><a class="btn" href="<?= e(url('user/add')) ?>">Tambah Pengguna</a></p>
 <table>
  <tr><th>No</th><th>Nama</th><th>Email</th><th>Dibuat</th><th>Aksi</th></tr>
  <?php if (!$users): ?>
   <tr><td colspan="5">Belum ada data pengguna.</td></tr>
  <?php endif; ?>
  <?php foreach ($users as $i => $u): ?>
  <tr>
   <td><?= $i + 1 ?></td>
   <td><?= e($u['nama']) ?></td>
   <td><?= e($u['email']) ?></td>
   <td><?= e(formatTanggal($u['created_at'])) ?></td>
   <td>
    <a href="<?= e(url('user/edit', ['id' => $u['id']])) ?>">Edit</a> |
    <form class="inline" method="post" action="<?= e(url('user/delete')) ?>"
          data-confirm="Hapus pengguna <?= e($u['nama']) ?>?">
     <?= csrf_field() ?>
     <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
     <button type="submit" class="btn link">Hapus</button>
    </form>
   </td>
  </tr>
  <?php endforeach; ?>
 </table>
</section>
