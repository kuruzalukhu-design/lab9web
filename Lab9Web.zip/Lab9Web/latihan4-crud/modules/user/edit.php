<?php
$id = get_id();
if ($id === null) {
    flash_set('error', 'ID pengguna tidak valid.');
    redirect(url('user/list'));
}
$stmt = $pdo->prepare('SELECT id, nama, email FROM users WHERE id = :id');
$stmt->execute([':id' => $id]);
$user = $stmt->fetch();
if (!$user) {
    flash_set('error', 'Pengguna tidak ditemukan.');
    redirect(url('user/list'));
}

$errors = [];
$nama   = $user['nama'];
$email  = $user['email'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $nama     = post_string('nama');
    $email    = post_string('email');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';

    $errors = validasi_user($pdo, $nama, $email, $password, false, $id);
    if (!$errors) {
        if ($password !== '') {
            $stmt = $pdo->prepare('UPDATE users SET nama = :nama, email = :email, password = :password WHERE id = :id');
            $stmt->execute([':nama' => $nama, ':email' => $email, ':password' => password_hash($password, PASSWORD_DEFAULT), ':id' => $id]);
        } else {
            $stmt = $pdo->prepare('UPDATE users SET nama = :nama, email = :email WHERE id = :id');
            $stmt->execute([':nama' => $nama, ':email' => $email, ':id' => $id]);
        }
        flash_set('success', 'Data pengguna berhasil diperbarui.');
        redirect(url('user/list'));
    }
}
?>
<section>
 <h2>Edit Pengguna</h2>
 <?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>
 <form method="post" action="<?= e(url('user/edit', ['id' => $id])) ?>">
  <?= csrf_field() ?>
  <div class="form-group"><label>Nama</label><input type="text" name="nama" value="<?= e($nama) ?>" required></div>
  <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($email) ?>" required></div>
  <div class="form-group"><label>Password baru (kosongkan jika tidak diganti)</label><input type="password" name="password"></div>
  <button class="btn" type="submit">Perbarui</button>
  <a href="<?= e(url('user/list')) ?>">Batal</a>
 </form>
</section>
