<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    redirect(url('login'));
}
csrf_verify();
unset($_SESSION['user']);
session_regenerate_id(true);
flash_set('success', 'Anda telah logout.');
redirect(url('login'));
