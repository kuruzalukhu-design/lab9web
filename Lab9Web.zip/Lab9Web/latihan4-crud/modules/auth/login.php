<?php
if (is_logged_in()) {
    redirect(url('dashboard'));
}
$errors = [];
$email  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email    = post_string('email');
    $password = is_string($_POST['password'] ?? null) ? $_POST['password'] : '';

    if (!validasiEmail($email) || $password === '') {
        $errors[] = 'Email dan password wajib diisi dengan benar.';
    } else {
        $stmt = $pdo->prepare('SELECT id, nama, email, password FROM users WHERE email = :email');
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            session_regenerate_id(true);
            $_SESSION['user'] = ['id' => (int) $user['id'], 'nama' => $user['nama'], 'email' => $user['email']];
            flash_set('success', 'Login berhasil. Selamat datang, ' . $user['nama'] . '!');
            redirect(url('dashboard'));
        }
        $errors[] = 'Email atau password salah.';
    }
}
?>
<section>
 <h2>Login</h2>
 <?php foreach ($errors as $err): ?><div class="flash error"><?= e($err) ?></div><?php endforeach; ?>
 <form method="post" action="<?= e(url('login')) ?>">
  <?= csrf_field() ?>
  <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($email) ?>" required></div>
  <div class="form-group"><label>Password</label><input type="password" name="password" required></div>
  <button class="btn" type="submit">Masuk</button>
 </form>
 <p><small>Akun contoh: admin@example.com / admin123</small></p>
</section>
