<?php require_once __DIR__ . '/header.php'; ?>
<section class="content">
 <h2>Kontak</h2>
 <p>Hubungi kami melalui email: praktikum@example.com.</p>
</section>
<?php require_once __DIR__ . '/footer.php'; ?>
