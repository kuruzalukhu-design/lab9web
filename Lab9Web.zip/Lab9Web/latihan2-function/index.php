<?php
require_once __DIR__ . '/helpers/functions.php';
$judul = 'Produk';
$produk = [
    ['nama' => 'Buku PHP Dasar', 'harga' => 85000,  'deskripsi' => 'Panduan lengkap belajar PHP dari variabel sampai database untuk pemula.'],
    ['nama' => 'Flashdisk 64GB', 'harga' => 120000, 'deskripsi' => 'Penyimpanan portabel kecepatan tinggi.'],
    ['nama' => 'Mouse Wireless', 'harga' => 95000,  'deskripsi' => 'Mouse nirkabel ergonomis dengan baterai tahan lama untuk kerja seharian.'],
];
$persenDiskon = 15;
require_once __DIR__ . '/views/header.php';
?>
<h2>Daftar Produk (diskon <?= $persenDiskon ?>%)</h2>
<table>
 <tr><th>Nama</th><th>Deskripsi</th><th>Harga</th><th>Diskon</th><th>Harga Akhir</th></tr>
 <?php foreach ($produk as $p):
    $diskon = hitungDiskon($p['harga'], $persenDiskon); ?>
 <tr>
  <td><?= e($p['nama']) ?></td>
  <td><?= e(ringkasTeks($p['deskripsi'], 40)) ?></td>
  <td><?= formatRupiah($p['harga']) ?></td>
  <td><?= formatRupiah($diskon) ?></td>
  <td><?= formatRupiah($p['harga'] - $diskon) ?></td>
 </tr>
 <?php endforeach; ?>
</table>
<?php require_once __DIR__ . '/views/footer.php'; ?>
