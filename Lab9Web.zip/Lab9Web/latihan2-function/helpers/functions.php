<?php
/** Escaping output HTML. */
function e(string $nilai): string {
    return htmlspecialchars($nilai, ENT_QUOTES, 'UTF-8');
}

/** Format angka ke Rupiah: 150000 -> "Rp 150.000". */
function formatRupiah(float $angka): string {
    return 'Rp ' . number_format($angka, 0, ',', '.');
}

/** Hitung nominal diskon. Contoh: hitungDiskon(200000, 15) -> 30000. */
function hitungDiskon(float $harga, float $persen = 10): float {
    if ($persen < 0 || $persen > 100) {
        return 0.0;
    }
    return $harga * ($persen / 100);
}

/** Validasi format email. Mengembalikan true jika valid. */
function validasiEmail(string $email): bool {
    return filter_var(trim($email), FILTER_VALIDATE_EMAIL) !== false;
}

/** Ringkas teks sampai $batas karakter, tambahkan "..." bila terpotong. */
function ringkasTeks(string $teks, int $batas = 50): string {
    $teks = trim($teks);
    if (mb_strlen($teks, 'UTF-8') <= $batas) {
        return $teks;
    }
    return rtrim(mb_substr($teks, 0, $batas, 'UTF-8')) . '...';
}
