<!DOCTYPE html>
<html lang="id">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <title><?= e($judul ?? 'Latihan 2') ?> - Library Function</title>
 <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
 <header><h1>Latihan 2 - Library Function</h1><p>helpers/functions.php</p></header>
 <nav>
  <a href="index.php">Produk</a>
  <a href="daftar.php">Daftar Email</a>
 </nav>
 <main>
