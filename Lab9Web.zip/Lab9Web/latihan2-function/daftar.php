<?php
require_once __DIR__ . '/helpers/functions.php';
$judul = 'Daftar Email';
$email = '';
$pesan = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    $pesan = validasiEmail($email)
        ? '<p>Email <strong>' . e($email) . '</strong> valid.</p>'
        : '<p class="error">Format email tidak valid.</p>';
}
require_once __DIR__ . '/views/header.php';
?>
<h2>Validasi Email</h2>
<form method="post" action="">
 <label>Email</label>
 <input type="text" name="email" value="<?= e($email) ?>">
 <button type="submit">Cek</button>
</form>
<?= $pesan ?>
<p>Ringkasan teks: <?= e(ringkasTeks('Function ringkasTeks memotong kalimat yang terlalu panjang agar muat di tabel.', 30)) ?></p>
<?php require_once __DIR__ . '/views/footer.php'; ?>
